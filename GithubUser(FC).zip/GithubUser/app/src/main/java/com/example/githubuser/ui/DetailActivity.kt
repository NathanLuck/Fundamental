package com.example.githubuser.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.viewModels
import androidx.annotation.StringRes
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import com.bumptech.glide.Glide
import com.example.githubuser.R
import com.example.githubuser.adapter.SectionPagerAdapter
import com.example.githubuser.database.FavoriteUser
import com.example.githubuser.databinding.ActivityDetailBinding
import com.example.githubuser.model.DetailViewModel
import com.example.githubuser.model.ViewModelFactory
import com.google.android.material.tabs.TabLayoutMediator


class DetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailBinding

    private val detailViewModel by viewModels<DetailViewModel>()
    {
        ViewModelFactory.getInstance(application)
    }
    private lateinit var favoriteUser: FavoriteUser
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val username = intent.getStringExtra(EXTRA_LOGIN)

        if(detailViewModel.detailUser.value==null) detailViewModel.getDetailUser(username.toString())

        var isFavorite = false
        detailViewModel.cekUserFavorite(username!!).observe(this){
            isFavorite = it
            if (it){
                binding.favoriteAdduser.setImageDrawable(ContextCompat.getDrawable(binding.favoriteAdduser.context,R.drawable.favorite))
            }
            else {
                binding.favoriteAdduser.setImageDrawable(ContextCompat.getDrawable(binding.favoriteAdduser.context,R.drawable.favorite_border))
            }
        }
        binding.favoriteAdduser.setOnClickListener{
            if (isFavorite){
                isFavorite = false
                binding.favoriteAdduser.setImageDrawable(ContextCompat.getDrawable(binding.favoriteAdduser.context, R.drawable.favorite_border))
                detailViewModel.deleteUserFavorite(favoriteUser)
            }
            else {
                isFavorite = true
                binding.favoriteAdduser.setImageDrawable(ContextCompat.getDrawable(binding.favoriteAdduser.context,R.drawable.favorite))
                detailViewModel.insertUserFavorite(favoriteUser)
            }
        }
        detailViewModel.detailUser.observe(this){
            it?.let{
                with(binding){
                    tvFollowers.text = it.followers.toString()
                    tvFollowing.text = it.following.toString()
                    tvName.text = it.name
                    tvUsername.text = it.login
                    Glide.with(binding.root)
                        .load(it.avatarUrl)
                        .into(binding.ivUser)
                        .clearOnDetach()
                }
                favoriteUser = FavoriteUser(it.login,it.name,it.avatarUrl,true,it.followers.toString(),it.following.toString())
            }
        }

        detailViewModel.isLoading.observe(this){
            binding.progressBar.isVisible = it
        }

        val sectionsPagerAdapter = SectionPagerAdapter(this)
        val viewPager = binding.viewPager
        viewPager.adapter = sectionsPagerAdapter
        val tabs = binding.tabLayout
        TabLayoutMediator(tabs, viewPager) { tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()
    }
    companion object{
        const val EXTRA_LOGIN="login"
        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.followers,
            R.string.following,
        )
    }
}