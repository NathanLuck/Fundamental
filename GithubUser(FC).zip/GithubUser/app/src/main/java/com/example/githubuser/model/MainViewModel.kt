package com.example.githubuser.model

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.githubuser.data.api.ApiConfig
import com.example.githubuser.data.response.GithubUserResponse
import com.example.githubuser.data.response.User
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainViewModel: ViewModel() {
    private var _listUser = MutableLiveData<List<User>>()
    val listUser: LiveData<List<User>> = _listUser

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val _isEmpty = MutableLiveData<Boolean>()
    val isEmpty: LiveData<Boolean> = _isEmpty

    init{
        searchUser("Nathan")
    }
    fun searchUser(username: String) {
        _isLoading.value = true
        val client = ApiConfig.getApiService().getSearchGithubUser(username)
        client.enqueue(object : Callback<GithubUserResponse> {
            override fun onResponse(
                call: Call<GithubUserResponse>,
                response: Response<GithubUserResponse>
            ) {
                _isLoading.value = false
                _listUser.value = response.body()?.items?: listOf()
            }

            override fun onFailure(call: Call<GithubUserResponse>, t: Throwable) {
                Log.e(FollowViewModel.TAG, "onFailureSearch: ${t.message.toString()}")
            }


        })
    }
    companion object{
        private const val TAG = "MainViewModel"
    }
}