package com.example.githubuser.model

import android.app.Application
import androidx.lifecycle.ViewModel
import com.example.githubuser.database.UserRepository


class FavoriteUserViewModel(application: Application) : ViewModel() {
    private val userRepository: UserRepository = UserRepository(application)

    fun getAllFavoriteUsers() = userRepository.getAllFavoriteUsers()

    init {
        getAllFavoriteUsers()
    }
}