package com.example.githubuser.ui

import com.example.githubuser.adapter.GithubUserAdapter
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.githubuser.R
import com.example.githubuser.darkmode.DarkModeActivity
import com.example.githubuser.darkmode.DarkModeModel
import com.example.githubuser.darkmode.SettingPreferences
import com.example.githubuser.darkmode.ViewModelFactory
import com.example.githubuser.darkmode.dataStore
import com.example.githubuser.data.response.User
import com.example.githubuser.databinding.ActivityMainBinding
import com.example.githubuser.model.MainViewModel


class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val mainViewModel by viewModels<MainViewModel>()
    private val darkModeModel by viewModels<DarkModeModel>{ ViewModelFactory(SettingPreferences.getInstance(application.dataStore)) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val layoutManager = LinearLayoutManager(this)
        binding.rvUser.layoutManager = layoutManager
        mainViewModel.listUser.observe(this){ listUser->
            setAdapter(listUser)
        }

        darkModeModel.getThemeSettings().observe(this) { isDarkModeActive: Boolean ->
            if (isDarkModeActive) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }
        }

        mainViewModel.isLoading.observe(this){
            binding.progressBar.isVisible = it
        }
        mainViewModel.isEmpty.observe(this){
            binding.tvEmpty.isVisible = it
        }
        with(binding) {
            svUser.setupWithSearchBar(sbUser)
            svUser
                .editText
                .setOnEditorActionListener { textView, actionId, event ->
                    sbUser.setText(svUser.text)
                    mainViewModel.searchUser(svUser.text.toString())
                    svUser.hide()
                    false
                }
        }
        binding.sbUser.setOnMenuItemClickListener { menuItem ->
            when (menuItem.itemId) {
                R.id.menu1 -> {
                    val intent = Intent(this, FavoriteUserActivity::class.java)
                    startActivity(intent)
                    true
                }
                R.id.menu2 -> {
                    val intent = Intent(this, DarkModeActivity::class.java)
                    startActivity(intent)
                    true
                }
                else -> false
            }
        }
    }
    private fun setAdapter(listUser: List<User>){
        val adapter = GithubUserAdapter()
        adapter.submitList(listUser)
        binding.rvUser.adapter = adapter
    }
}