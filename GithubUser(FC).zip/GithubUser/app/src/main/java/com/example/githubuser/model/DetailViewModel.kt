package com.example.githubuser.model
import android.app.Application
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.githubuser.data.api.ApiConfig
import com.example.githubuser.data.response.DetailUserResponse
import com.example.githubuser.database.FavoriteUser
import com.example.githubuser.database.UserRepository
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailViewModel(mApplication: Application) : ViewModel() {
    private val userRepository: UserRepository = UserRepository(mApplication)
    private val _detailUser = MutableLiveData<DetailUserResponse?>()
    val detailUser: LiveData<DetailUserResponse?> = _detailUser

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    fun insertUserFavorite(favoriteUser: FavoriteUser) {
        userRepository.insert(favoriteUser)
    }

    fun deleteUserFavorite(favoriteUser: FavoriteUser) {
        userRepository.delete(favoriteUser)
    }

    fun cekUserFavorite(username: String):LiveData<Boolean>{
        return userRepository.isFavorite(username)
    }


    fun getDetailUser(username: String) {
        _isLoading.value = true
        val client = ApiConfig.getApiService().getDetailUser(username)
        client.enqueue(object : Callback<DetailUserResponse> {
            override fun onResponse(
                call: Call<DetailUserResponse>,
                response: Response<DetailUserResponse>
            ) {
                _isLoading.value = false
                if (response.isSuccessful) {
                    _detailUser.value = response.body()
                } else {
                    Log.e(TAG, "onFailureDetail: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<DetailUserResponse>, t: Throwable) {
                _isLoading.value = false
                Log.e(TAG, "onFailureDetail: ${t.message.toString()}")
            }
        })
    }
    companion object{
        private const val TAG = "DetailViewModel"
    }
}